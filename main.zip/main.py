
def is_prime(n: int) -> bool:
    """בדיקה אם מספר הוא ראשוני בלי while"""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    for i in range(5, int(n ** 0.5) + 1, 6):
        if n % i == 0 or n % (i + 2) == 0:
            return False
    return True
def twin_of_prime(p: int) -> int | None:
    """
    מקבל מספר ראשוני ומחזיר את התאום שלו אם קיים.
    אם אין תאום או שהקלט אינו ראשוני – מחזיר None.
    """
    if not is_prime(p):
        return None
    if is_prime(p - 2):
        return p - 2
    if is_prime(p + 2):
        return p + 2
    return None

def main():
    user_input = input("enter number: ")
    try:
        num = int(user_input)
        result = twin_of_prime(num)
        if result is None:
            print("invalid input")
        else:
            print(result)
    except ValueError:
        print("invalid input")

if __name__ == "__main__":
    main()
